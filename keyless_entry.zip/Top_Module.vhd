library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.NUMERIC_STD.ALL;

entity keyless is
    Port (
        clk       : in  STD_LOGIC;
        reset     : in  STD_LOGIC;
        row       : in  STD_LOGIC_VECTOR(3 downto 0);
        col       : out STD_LOGIC_VECTOR(3 downto 0);
        B_output  : out STD_LOGIC_VECTOR(31 downto 0);
        debug_state : out STD_LOGIC_VECTOR(2 downto 0);
        lcd_rs    : out STD_LOGIC;
        lcd_en    : out STD_LOGIC;
        lcd_rw    : out STD_LOGIC;
		  x    : out STD_LOGIC;
		  b    : out STD_LOGIC;
		  c    : out STD_LOGIC;
		  d    : out STD_LOGIC
        
    );
end keyless;

architecture Behavioral of keyless is
    type state is (Idle, Input, Check, Success, Failure, NewPassword, UpdateCheck);
	 signal flag3 : std_logic :='0';-- LCD control flag
	 signal flag2 : std_logic :='0';-- LCD control flag
	 signal flag1 : std_logic :='0';-- LCD control flag
 	 signal flag : std_logic :='0';-- LCD control flag
    signal prev_state : state := Idle;
    signal next_state : state := Idle;
    signal state_debug : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal cntr : integer range 0 to 55000000 := 0;
    signal CLK1sn : STD_LOGIC := '0';
    signal B_internal : STD_LOGIC_VECTOR(31 downto 0) := (others => '0');
    signal A : STD_LOGIC_VECTOR(23 downto 0) := "000100100011010001010110"; -- default password
    signal B_temp : STD_LOGIC_VECTOR(23 downto 0) := (others => '0');

	 

    component keypad_test
        Port (
            clk       : in  STD_LOGIC;
            reset     : in  STD_LOGIC;
            row       : in  STD_LOGIC_VECTOR(3 downto 0); -- keypad
            col       : out STD_LOGIC_VECTOR(3 downto 0); -- keypad
            B         : out STD_LOGIC_VECTOR(31 downto 0) -- keypad

        );
    end component;
	     -- LCD Mod�l� ��in Bile�en Tan�m�
    component lcd_controller
        Port (
        clk : in std_logic;
        flag : in std_logic;
		  flag1: in std_logic;
		  flag2: in std_logic;
		  flag3: in std_logic;
        e : out std_logic; --enable bit
        rs : out std_logic; -- rs bit
        rw : out std_logic; --rw bit
        d : out std_logic; -- data
        c : out std_logic; -- data
        b : out std_logic; -- data
        x : out std_logic -- data
        );
    end component;

begin
    -- Clock Divider (2... Sn)
    CLKDIV: process(clk, cntr, CLK1sn)
    begin
        if rising_edge(clk) then
            if cntr = 55000000 then
                cntr <= 0;
                CLK1sn <= not CLK1sn;
            else
                cntr <= cntr + 1;
            end if;
        end if;
    end process;

    -- Keypad modul instantiation
    keypad_inst : keypad_test
        port map (
            clk => clk,
            reset => reset,
            row => row,
            col => col,
            B => B_internal

        );
    -- LCD instantiation
    lcd_inst : lcd_controller
        port map (
            clk => clk,
				flag=>flag,
				flag1=>flag1,
				flag2=>flag2,
				flag3=>flag3,
            rs => lcd_rs,
            e => lcd_en,
            rw => lcd_rw,
            x=>x,
				b=>b,
				c=>c,
				d=>d				            
        );
		  
    -- State Machine
    process(prev_state, B_internal)
    begin
        case prev_state is
            
				when Idle => -- Idle state
                state_debug <= "000";
					 flag3<='0';
                flag2<='0';
					 flag1<='0';
                if B_internal(3 downto 0) = "1110" then -- * key
                    next_state <= Input;
                else
                    next_state <= Idle;
                end if;
            
				when Input =>
                state_debug <= "001";
					 flag<='1';
                if B_internal(3 downto 0) = "1101" or B_internal(3 downto 0) = "1100" then -- C or D
                    next_state <= UpdateCheck;
                else
                    next_state <= Input;
                end if;
            
				when UpdateCheck => --internal state
					 flag <='0';
                state_debug <= "110";
                B_temp <= B_internal(27 downto 4);
                next_state <= Check;
           
			  when Check =>  -- Check password if it is true
                state_debug <= "010";               					 
                if A = B_temp and B_internal(3 downto 0) = "1101" then --Check pressed D 
                    next_state <= Success;
                elsif A = B_temp and B_internal(3 downto 0) = "1100" then --Check pressed C 
                    next_state <= NewPassword; 
                else
                    next_state <= Failure;
                end if;

            when Success =>
                state_debug <= "011";
					 flag3<='1';              					 
                next_state <= Idle;

            when NewPassword =>
                state_debug <= "100";
					 flag1<='1';					
                if B_internal(3 downto 0) = "1010" then -- A key
                    next_state <= Success ;   
                else
                    next_state <= NewPassword;             
                end if;

            when Failure =>
                state_debug <= "101";
					 flag2<='1';               					
                next_state <= Idle;
           
            when others =>
                state_debug <= "111";                					
                next_state <= Idle;
          
        end case;
    end process;
    process(CLK1sn, reset)
    begin
        if reset = '1' then
            prev_state <= Idle;
        
            A <= (others => '0'); 
        elsif rising_edge(CLK1sn) then
            prev_state <= next_state;
       

            -- Update A in NewPassword
            if prev_state = NewPassword and B_internal(3 downto 0) = "1010" then --A Key
                A <= B_internal(27 downto 4); -- Update new password
            end if;
        end if;
    end process;

    -- Output Assignments
    B_output <= B_internal;
    debug_state <= state_debug;

end Behavioral;