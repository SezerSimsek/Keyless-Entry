library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity lcd_controller is
    Port (
        clk : in std_logic;
        flag : in std_logic;
        flag1 : in std_logic;
		  flag2: in std_logic;
		  flag3: in std_logic;
        e : out std_logic;
        rs : out std_logic;
        rw : out std_logic;
        d : out std_logic;
        c : out std_logic;
        b : out std_logic;
        x : out std_logic
    );
end lcd_controller;

architecture Behavioral of lcd_controller is

    signal count : std_logic_vector(26 downto 0) := (others => '0');
    signal code : std_logic_vector(5 downto 0);
	 signal e_signal : std_logic := '0'; -- check 'e' signal
    signal done : std_logic := '0'; -- if message sent or not


begin

    process(clk)
    begin
        if rising_edge(clk) then
            if (flag1 = '0' and flag = '1' and flag2='0' and flag3='0') then -- enter password
                -- Increment count
					 
					 if count(20) = '1' then
                    e_signal <= '1'; -- `e` enable
                else
                    e_signal <= '0'; -- `e` unenable
                end if;
                if count = "111111111111111111111111111" then --count
                    count <= (others => '0');
					 end if;
					 if done='0' then
                    count <= count + 1;
					 end if;
                

                -- "Enter Password" message
					 if done='0' then
                case count(26 downto 21) is
                    when "000000" => code <= "000011"; -- Power-on init sequence
                    when "000001" => code <= "000011";
                    when "000010" => code <= "000011";
                    when "000011" => code <= "000010";

                    -- Function Set
                    when "000100" => code <= "000010";
                    when "000101" => code <= "001000";

                    -- Entry Mode
                    when "000110" => code <= "000000";
                    when "000111" => code <= "000110";

                    -- Display On/Off
                    when "001000" => code <= "000000";
                    when "001001" => code <= "001100";

                    -- Clear Display
                    when "001010" => code <= "000000";
                    when "001011" => code <= "000001";

                    -- Characters to Display "Enter Password"
                    when "001100" => code <= "100100"; -- 'E' high nibble
                    when "001101" => code <= "100101"; -- 'E' low nibble
                    when "001110" => code <= "100100"; -- 'n' high nibble
                    when "001111" => code <= "101110"; -- 'n' low nibble
                    when "010000" => code <= "100101"; -- 't' high nibble
                    when "010001" => code <= "100100"; -- 't' low nibble
                    when "010010" => code <= "100100"; -- 'e' high nibble
                    when "010011" => code <= "100101"; -- 'e' low nibble
                    when "010100" => code <= "100101"; -- 'r' high nibble
                    when "010101" => code <= "100010"; -- 'r' low nibble

                    -- Space 2 line mode
                    when "010110" => code <= "001100"; -- Space high nibble
                    when "010111" => code <= "000000"; -- Space low nibble

                    -- Password Line
                    when "011000" => code <= "100101"; -- 'P' high nibble
                    when "011001" => code <= "100000"; -- 'P' low nibble
                    when "011010" => code <= "100100"; -- 'a' high nibble
                    when "011011" => code <= "100001"; -- 'a' low nibble
                    when "011100" => code <= "100101"; -- 's' high nibble
                    when "011101" => code <= "100011"; -- 's' low nibble
                    when "011110" => code <= "100101"; -- 's' high nibble
                    when "011111" => code <= "100011"; -- 's' low nibble
                    when "100000" => code <= "100101"; -- 'w' high nibble
                    when "100001" => code <= "100111"; -- 'w' low nibble
                    when "100010" => code <= "100100"; -- 'o' high nibble
                    when "100011" => code <= "101111"; -- 'o' low nibble
                    when "100100" => code <= "100101"; -- 'r' high nibble
                    when "100101" => code <= "100010"; -- 'r' low nibble
                    when "100110" => code <= "100100"; -- 'd' high nibble
                    when "100111" => code <= "100100"; -- 'd' low nibble

                    -- Idle
                    when others => 
							code <= "100001";
							done<='1';
							
                end case;
					 end if;

            elsif  (flag1 = '1' and flag = '0' and flag2='0' and flag3='0') then -- newpassword
					 done<='0';
					 if count(20) = '1' then
                    e_signal <= '1'; 
                else
                    e_signal <= '0'; 
                end if;
                if count = "111111111111111111111111111" then
                    count <= (others => '0');
					 end if;
					 if done='0' then
                    count <= count + 1;
					 end if;

                case count(26 downto 21) is
                    when "000000" => code <= "000011"; -- Power-on init sequence
                    when "000001" => code <= "000011";
                    when "000010" => code <= "000011";
                    when "000011" => code <= "000010";

                    -- Function Set
                    when "000100" => code <= "000010";
                    when "000101" => code <= "001000";

                    -- Entry Mode
                    when "000110" => code <= "000000";
                    when "000111" => code <= "000110";

                    -- Display On/Off
                    when "001000" => code <= "000000";
                    when "001001" => code <= "001100";

                    -- Clear Display
                    when "001010" => code <= "000000";
                    when "001011" => code <= "000001";
                    
                    when "001100" => code <= "100100"; -- 'N' high nibble
                    when "001101" => code <= "101110"; -- 'N' low nibble
                    when "001110" => code <= "100100"; -- 'e'
                    when "001111" => code <= "100101";
                    when "010000" => code <= "100101"; -- 'w'
                    when "010001" => code <= "100111";
						  -- Set DDRAM Address for Line 2
						  when "010010" => code <= "001100";
						  when "010011" => code <= "000000";
						  
							-- Characters for Line 2
                    when "010100" => code <= "100101"; -- 'p'
                    when "010101" => code <= "100000";
                    when "010110" => code <= "100100"; -- 'a'
                    when "010111" => code <= "100001";                   
                    when "011000" => code <= "100101"; -- 's'
                    when "011001" => code <= "100011";
                    when "011010" => code <= "100101"; -- 's'
                    when "011011" => code <= "100011";
                    when "011100" => code <= "100101"; -- 'w'
                    when "011101" => code <= "100111";
                    when "011110" => code <= "100100"; -- 'o'
                    when "011111" => code <= "101111";
                    when "100000" => code <= "100101"; -- 'r'
                    when "100001" => code <= "100010";
                    when "100010" => code <= "100110"; -- 'd'
                    when "100011" => code <= "100100";
                    when "100100" => code <= "100010"; -- '!'
                    when "100101" => code <= "100001";

                    -- Idle
                    when others => 
							code <= "100001";
							done<='1';
                end case;
            elsif (flag1 = '0' and flag = '0' and flag2='1' and flag3='0') then -- failure
                -- Increment count
					 done<='0';
					 if count(20) = '1' then
                    e_signal <= '1'; 
                else
                    e_signal <= '0'; 
                end if;
                if count = "111111111111111111111111111" then
                    count <= (others => '0');
                else
                    count <= count + 1;
                end if;
              
                case count(26 downto 21) is
                    when "000000" => code <= "000011"; -- Power-on init sequence
                    when "000001" => code <= "000011";
                    when "000010" => code <= "000011";
                    when "000011" => code <= "000010";

                    -- Function Set
                    when "000100" => code <= "000010";
                    when "000101" => code <= "001000";

                    -- Entry Mode
                    when "000110" => code <= "000000";
                    when "000111" => code <= "000110";

                    -- Display On/Off
                    when "001000" => code <= "000000";
                    when "001001" => code <= "001100";

                    -- Clear Display
                    when "001010" => code <= "000000";
                    when "001011" => code <= "000001";

                    -- Characters to Display "Hello, World!"
						  when "001100" => code <= "100100"; -- 'F' high nibble
                    when "001101" => code <= "100110"; -- 'F' low nibble
                    when "001110" => code <= "100100"; -- 'A' high nibble
                    when "001111" => code <= "100001"; -- 'A' low nibble
                    when "010000" => code <= "100100"; -- 'I' high nibble
                    when "010001" => code <= "101001"; -- 'I' low nibble
                    when "010010" => code <= "100100"; -- 'L' high nibble
                    when "010011" => code <= "101100"; -- 'L' low nibble
                    when "010100" => code <= "100101"; -- 'U' high nibble
                    when "010101" => code <= "100101"; -- 'U' low nibble
                    when "010110" => code <= "100101"; -- 'R' high nibble
						  when "010111" => code <= "100010"; -- 'R' low nibble
						  when "011000" => code <= "100100"; -- 'E' high nibble
						  when "011001" => code <= "100101"; -- 'E' low nibble

                    -- Idle
                    when others => 
							code <= "100001";
							done<='1';
                end case;
           elsif (flag1 = '0' and flag = '0' and flag2='0' and flag3='1') then  --succes
					 done<='0';
					 if count(20) = '1' then
                    e_signal <= '1'; 
                else
                    e_signal <= '0'; 
                end if;
                if count = "111111111111111111111111111" then
                    count <= (others => '0');
                else
                    count <= count + 1;
                end if;

                case count(26 downto 21) is
                    when "000000" => code <= "000011"; -- Power-on init sequence
                    when "000001" => code <= "000011";
                    when "000010" => code <= "000011";
                    when "000011" => code <= "000010";

                    -- Function Set
                    when "000100" => code <= "000010";
                    when "000101" => code <= "001000";

                    -- Entry Mode
                    when "000110" => code <= "000000";
                    when "000111" => code <= "000110";

                    -- Display On/Off
                    when "001000" => code <= "000000";
                    when "001001" => code <= "001100";

                    -- Clear Display
                    when "001010" => code <= "000000";
                    when "001011" => code <= "000001";

                    -- Characters to Display "Hello, World!"
                    when "001100" => code <= "100101"; -- 'S' high nibble
                    when "001101" => code <= "100011"; -- 'S' low nibble
                    when "001110" => code <= "100101"; -- 'u'
                    when "001111" => code <= "100101";
                    when "010000" => code <= "100100"; -- 'c'
                    when "010001" => code <= "100011";
                    when "010010" => code <= "100100"; -- 'c'
                    when "010011" => code <= "100011";
                    when "010100" => code <= "100100"; -- 'e'
                    when "010101" => code <= "100101";
                    when "010110" => code <= "100101"; -- 's'
                    when "010111" => code <= "100011";                   
                    -- Idle
                    when others => 
							code <= "100001";
							done<='1';
                end case;

            else
                -- Reset outputs when neither flag is active
                count <= (others => '0');
                e <= '0';
                rs <= '0';
                rw <= '0';
                d <= '0';
                c <= '0';
                b <= '0';
                x <= '0';
					 done<='0';
            end if;

            

            -- Assign individual outputs
            e <= e_signal;
            rs <= code(5);
            rw <= code(4);
            d <= code(3);
            c <= code(2);
            b <= code(1);
            x <= code(0);
        end if;
    end process;

end Behavioral;
