library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.NUMERIC_STD.ALL;

entity keypad_test is
    Port (
        clk       : in  STD_LOGIC;
        reset     : in  STD_LOGIC;
        row       : in  STD_LOGIC_VECTOR(3 downto 0);
        col       : out STD_LOGIC_VECTOR(3 downto 0);
        B         : out STD_LOGIC_VECTOR(31 downto 0)

    );
end keypad_test;

architecture Behavioral of keypad_test is
    signal col_index     : INTEGER range 0 to 3 := 0;
    signal row_state     : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal debounce_cntr : INTEGER := 0;
    signal key_detected  : BOOLEAN := FALSE;
    signal scan_cntr     : INTEGER := 0;
    signal B_internal    : STD_LOGIC_VECTOR(31 downto 0) := (others => '0');
    signal current_key   : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal last_key      : STD_LOGIC_VECTOR(3 downto 0) := (others => '0'); 
    constant DEBOUNCE_LIMIT : INTEGER := 1000000; -- 20ms debounce  (50 MHz clock)
    constant SCAN_DELAY     : INTEGER := 400000; -- 8ms delay (50 MHz clock)
 

begin

    -- check col
    process(clk, reset)
    begin
        if reset = '1' then
            col_index <= 0;
            col <= "1110";
            scan_cntr <= 0;
				

        elsif rising_edge(clk) then
            scan_cntr <= scan_cntr + 1;
            if scan_cntr >= SCAN_DELAY then
                scan_cntr <= 0;
                col_index <= (col_index + 1) mod 4;
                case col_index is
                    when 0 => col <= "1110";
                    when 1 => col <= "1101";
                    when 2 => col <= "1011";
                    when 3 => col <= "0111";
                    when others => col <= "1111";
                end case;
            end if;
        end if;
    end process;

    -- reset
    process(clk, reset)
    begin
        if reset = '1' then
            row_state <= (others => '0');
            debounce_cntr <= 0;
            key_detected <= FALSE;
            B_internal <= (others => '0');
            last_key <= (others => '0');
				

				
        elsif rising_edge(clk) then
            if row /= "0000" then
                if key_detected = FALSE then
                    debounce_cntr <= debounce_cntr + 1;
                    if debounce_cntr > DEBOUNCE_LIMIT then
                        debounce_cntr <= 0;
                        key_detected <= TRUE;
                        row_state <= row;

                        -- Determine which key is active
                        case col_index is
                            when 0 =>
                                case row is
                                    when "0001" => current_key <= "0001"; -- 1
                                    when "0010" => current_key <= "0100"; -- 4
                                    when "0100" => current_key <= "0111"; -- 7
                                    when "1000" => current_key <= "1110"; -- *
                                    when others => current_key <= "0000";
                                end case;
                            when 1 =>
                                case row is
                                    when "0001" => current_key <= "0010"; -- 2
                                    when "0010" => current_key <= "0101"; -- 5
                                    when "0100" => current_key <= "1000"; -- 8
                                    when "1000" => current_key <= "0000"; -- 0
                                    when others => current_key <= "0000";
                                end case;
                            when 2 =>
                                case row is
                                    when "0001" => current_key <= "0011"; -- 3
                                    when "0010" => current_key <= "0110"; -- 6
                                    when "0100" => current_key <= "1001"; -- 9
                                    when "1000" => current_key <= "1111"; -- #
                                    when others => current_key <= "0000";
                                end case;
                            when 3 =>
                                case row is
                                    when "0001" => current_key <= "1010"; -- A
                                    when "0010" => current_key <= "1011"; -- B
                                    when "0100" => current_key <= "1100"; -- C
                                    when "1000" => current_key <= "1101"; -- D
                                    when others => current_key <= "0000";
                                end case;
                            when others =>
                                current_key <= "0000";
                        end case;

                        -- Update B_internal
                        if current_key /= last_key then
                            B_internal <= B_internal(27 downto 0) & current_key;
                            last_key <= current_key;
                        end if;

                    end if;
                end if;
            else
                debounce_cntr <= 0;
                key_detected <= FALSE;
            end if;
        end if;
    end process;

    -- Out B
    B <= B_internal;



end Behavioral;
